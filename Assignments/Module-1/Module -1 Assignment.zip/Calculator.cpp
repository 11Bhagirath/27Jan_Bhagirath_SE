#include<stdio.h>
main()
{
	int a=88, b=25;
	printf("Value of A is:%d",a);
	printf("\nValue of B is:%d",b);
	printf("\nAdd:%d",a+b);
	printf("\nSub:%d",a-b);
	printf("\nMul:%d",a*b);
	printf("\nDiv:%d",a/b);
}
